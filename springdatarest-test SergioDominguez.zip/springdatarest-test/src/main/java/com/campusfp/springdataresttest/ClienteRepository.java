package com.campusfp.springdataresttest;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface ClienteRepository  extends CrudRepository<ClienteEntity, Long>  {
	
	public List<ClienteEntity> findByNameIgnoreCaseContaining(@Param("nombre") String nombre);
}
