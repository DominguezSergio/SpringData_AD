package com.campusfp.springdataresttest;

import org.springframework.data.repository.CrudRepository;

public interface CiudadRepository extends CrudRepository<CiudadEntity, Integer>{

}
